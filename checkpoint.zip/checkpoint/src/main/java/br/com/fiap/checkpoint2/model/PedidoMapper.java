package br.com.fiap.checkpoint2.model;

import org.springframework.stereotype.Component;

@Component
public class PedidoMapper {

	public Pedido toPedido(PedidoDto dto) {
		return new Pedido(dto.getDataPedido(), dto.getDataCadastro(), dto.getValorTotal());
	}

}
