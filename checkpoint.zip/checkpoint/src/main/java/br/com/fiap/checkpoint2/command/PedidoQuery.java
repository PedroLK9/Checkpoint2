package br.com.fiap.checkpoint2.command;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.fiap.checkpoint2.model.Pedido;
import br.com.fiap.checkpoint2.repository.PedidoRepository;

@Component
public class PedidoQuery {

	@Autowired
	private PedidoRepository postRepository;

	public List<Pedido> executar() {
		return postRepository.findAll();
	}

}
