package br.com.fiap.checkpoint2.model;

public class PedidoId {

}
