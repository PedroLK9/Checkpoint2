package br.com.fiap.checkpoint2.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.fiap.checkpoint2.repository.PedidoRepository;

@Component
public class PedidoDelete implements UseCase {

	@Autowired
	private PedidoRepository postRepository;

	@Override
	public Object executar(Object... params) {
		postRepository.deleteById((Long) params[0]);
		return null;
	}
}
