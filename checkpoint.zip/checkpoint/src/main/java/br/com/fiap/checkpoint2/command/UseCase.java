package br.com.fiap.checkpoint2.command;


public interface UseCase {
	Object executar(Object ...params );
}
