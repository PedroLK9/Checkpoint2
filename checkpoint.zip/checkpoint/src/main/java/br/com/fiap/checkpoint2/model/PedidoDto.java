package br.com.fiap.checkpoint2.model;

import java.math.BigDecimal;
import java.time.Instant;

public class PedidoDto {

	private Instant dataPedido;
	private Instant dataCadastro;
	private BigDecimal valorTotal;

	public Instant getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(Instant dataPedido) {
		this.dataPedido = dataPedido;
	}

	public Instant getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Instant dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

}
