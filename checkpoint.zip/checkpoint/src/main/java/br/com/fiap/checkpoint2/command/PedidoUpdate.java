package br.com.fiap.checkpoint2.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.fiap.checkpoint2.model.Pedido;
import br.com.fiap.checkpoint2.repository.PedidoRepository;

@Component
public class PedidoUpdate implements UseCase {

	@Autowired
	private PedidoRepository postRepository;

	@Override
	public Object executar(Object... params) {

		Pedido savedPost = postRepository.save((Pedido) params[0]);
		return savedPost;
	}

}
