package br.com.fiap.checkpoint2.model;

import java.math.BigDecimal;
//import java.time.Instant;
//import java.time.LocalDateTime;
//import java.time.ZoneId;
//import java.time.format.DateTimeFormatter;
//import java.util.Locale;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_posts")
public class Pedido {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long codigoCliente;

	@Column(name = "data_pedido", nullable = false)
	private String dataPedido;

	@Column(name = "data_cadastro", nullable = false)
	private String dataCadastro;

	@Column(name = "valor_total", nullable = false)
	private BigDecimal valorTotal;

	public Pedido(String dataPedido, String dataCadastro, BigDecimal valorTotal) {
		this.dataPedido = dataPedido;
		this.dataCadastro = dataCadastro;
		this.valorTotal = valorTotal;
	}

	public Long getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(Long codigoCliente) {
		this.codigoCliente = codigoCliente;
	}

	public String getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(String dataPedido) {
		this.dataPedido = dataPedido;

	}

	public String getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(String dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Pedido [codigoCliente=");
		builder.append(codigoCliente);
		builder.append(", dataPedido=");
		builder.append(dataPedido);
		builder.append(", dataCadastro=");
		builder.append(dataCadastro);
		builder.append(", valorTotal=");
		builder.append(valorTotal);
		builder.append("]");
		return builder.toString();
	}

}
