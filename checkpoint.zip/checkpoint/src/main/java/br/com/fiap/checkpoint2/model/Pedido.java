package br.com.fiap.checkpoint2.model;

import java.math.BigDecimal;
import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tb_pedido")
public class Pedido {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long codigoCliente;

	@Column(name = "data_pedido", nullable = false)
	private Instant dataPedido;

	@Column(name = "data_cadastro", nullable = false)
	private Instant dataCadastro;

	@Column(name = "valor_total", nullable = false)
	private BigDecimal valorTotal;

	public Pedido(Instant dataPedido, Instant dataCadastro, BigDecimal valorTotal) {
		this.dataPedido = dataPedido;
		this.dataCadastro = dataCadastro;
		this.valorTotal = valorTotal;
	}

	public Long getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(Long codigoCliente) {
		this.codigoCliente = codigoCliente;
	}

	public Instant getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(Instant dataPedido) {
		this.dataPedido = dataPedido;

	}

	public Instant getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Instant dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Pedido [codigoCliente=");
		builder.append(codigoCliente);
		builder.append(", dataPedido=");
		builder.append(dataPedido);
		builder.append(", dataCadastro=");
		builder.append(dataCadastro);
		builder.append(", valorTotal=");
		builder.append(valorTotal);
		builder.append("]");
		return builder.toString();
	}

}
