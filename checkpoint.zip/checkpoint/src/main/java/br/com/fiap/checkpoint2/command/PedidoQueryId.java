package br.com.fiap.checkpoint2.command;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.fiap.checkpoint2.model.Pedido;
import br.com.fiap.checkpoint2.repository.PedidoRepository;

@Component
public class PedidoQueryId implements UseCase {

	@Autowired
	private PedidoRepository postRepository;

	public Optional<Pedido> executar(Object... params) {
		Long codigoCliente = (Long) params[0];
		Optional<Pedido> pedidoId = postRepository.findById(codigoCliente);
		return pedidoId;
	}

}
