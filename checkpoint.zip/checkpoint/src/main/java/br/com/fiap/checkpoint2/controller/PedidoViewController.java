package br.com.fiap.checkpoint2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.fiap.checkpoint2.command.PedidoDelete;
import br.com.fiap.checkpoint2.command.PedidoQuery;
import br.com.fiap.checkpoint2.command.PedidoQueryId;
import br.com.fiap.checkpoint2.command.PedidoUpdate;
import br.com.fiap.checkpoint2.model.Pedido;
import br.com.fiap.checkpoint2.model.PedidoDto;
import br.com.fiap.checkpoint2.model.PedidoMapper;
import br.com.fiap.checkpoint2.repository.PedidoRepository;

@RestController
@RequestMapping("pedidos")
public class PedidoViewController {

	private PedidoRepository postRepository;

	@Autowired
	private PedidoDelete deletar;

	@Autowired
	private PedidoUpdate alterar;

	@Autowired
	private PedidoQueryId buscaId;

	@Autowired
	private PedidoQuery busca;

	@Autowired
	PedidoMapper pedidoMapper;

	public PedidoViewController(PedidoRepository postRepository) {
		this.postRepository = postRepository;
	}

	@PostMapping("create")
	public Pedido create(@RequestBody PedidoDto pedidoDto) {

		Pedido pedido = pedidoMapper.toPedido(pedidoDto);

		return postRepository.save(pedido);
	}

	@GetMapping("/query")
	public List<Pedido> listAll() {
		List<Pedido> pedidos = busca.executar();
		return pedidos;
	}

	@GetMapping("/queryId")
	public Optional<Pedido> findById(@RequestBody Long codigoCliente) {
		Optional<Pedido> pedidoId = buscaId.executar(codigoCliente);
		return pedidoId;
	}

	@DeleteMapping("/delete")
	public void delete(@PathVariable Long codigoCliente) {
		deletar.executar(codigoCliente);
	}

	@PutMapping("/update")
	public Pedido savePost(@RequestBody Pedido post) {
		Pedido savedPost = (Pedido) alterar.executar(post);
		return savedPost;
	}

}
